namespace Q2_ItemsJoin.Models
{
    public class ItemName
    {
        public int Sno { get; set; }
        public int Id { get; set; }
        public string Iname { get; set; } = "";
    }
}
