namespace Q2_ItemsJoin.Models
{
    public class ItemPrice
    {
        public int Id { get; set; }
        public decimal Price { get; set; }
    }
}
